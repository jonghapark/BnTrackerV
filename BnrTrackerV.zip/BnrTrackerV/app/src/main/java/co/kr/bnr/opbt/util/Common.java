package co.kr.bnr.opbt.util;

public class Common {
    public static boolean isShowRawData = false;
}
